﻿
public interface ActionBase
{
    void Action();
}

public enum ActionDummy
{
    Dummy = 0
}