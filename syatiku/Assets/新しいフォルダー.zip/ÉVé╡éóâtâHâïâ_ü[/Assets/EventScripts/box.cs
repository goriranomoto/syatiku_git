using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class box : MonoBehaviour
{
void Start() {
    Destroy(gameObject,0.5f);
}


        // IEnumerator ChangeColor()
        // {
        //     if (masako.ZBox)
        //     {
        //         gameObject.SetActive(true);

        //     }

        //     yield return new WaitForSeconds(0.1f);
        //     gameObject.SetActive(false);
        // }
    }


