﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Appear : MonoBehaviour,ActionBase {
	public  void Action(){
		gameObject.SetActive(true);
	}
}
