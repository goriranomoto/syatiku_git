using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
public sealed class masako : MonoBehaviour
{
    //public static bool KZ;
    // public static bool ZBox;
    public static bool KZ = false;
    public static bool ZBox = false;

    public GameObject hitTrigger;


    /// <summary>
    /// 連続入力を禁止する
    /// </summary>
    public static class MyInput
    {
        static bool isCheck_Input;
        static bool preventContinuityInput;

        static float buttonDownTime;
        static float timer;


        /// <summary>
        /// Simultaneous input prohibited
        /// </summary>
        /// <param name="key"></param>
        /// <returns></returns>
        public static bool MyInputKeyDown(KeyCode key)
        {
            if (Input.anyKeyDown == false) isCheck_Input = false;

            if (isCheck_Input == false)
            {
                if (Input.GetKeyDown(key))
                {
                    isCheck_Input = true;
                    return true;
                }
            }
            return false;
        }

        /// <summary>
        /// Continuity input prohibited
        /// </summary>
        /// <param name="key"></param>
        /// <param name="intervalSeconds"></param>
        /// <returns></returns>
        public static bool MyInputKeydown(KeyCode key, float intervalSeconds)
        {
            timer = Time.time;

            if (Input.GetKeyDown(key) && timer - buttonDownTime >= intervalSeconds)
            {
                if (preventContinuityInput == false)
                {
                    preventContinuityInput = true;
                    buttonDownTime = Time.time;
                    return true;
                }
                else if (preventContinuityInput)
                {
                    preventContinuityInput = false;
                    buttonDownTime = Time.time;
                    return true;
                }
            }

            return false;
        }
    }



    void Update()
    {
        if (MyInput.MyInputKeyDown(KeyCode.Z))
        {
            print("Z");
            KZ = true;
            ZBox = true;
            Instantiate(hitTrigger,new Vector3(0,0,0),Quaternion.identity);
            Debug.Log("koko");
        }
        else if (MyInput.MyInputKeyDown(KeyCode.X))
        {
            print("X");
        }
        else if (MyInput.MyInputKeyDown(KeyCode.C))
        {
            print("C");
        }
        else if (MyInput.MyInputKeyDown(KeyCode.V))
        {
            print("V");
        }
        else if (MyInput.MyInputKeyDown(KeyCode.B))
        {
            print("B");
        }
        else if (MyInput.MyInputKeyDown(KeyCode.N))
        {
            print("N");
        }
        else if (MyInput.MyInputKeyDown(KeyCode.M))
        {
            print("M");
        }
        else if (MyInput.MyInputKeyDown(KeyCode.A))
        {
            print("A");
        }
        else if (MyInput.MyInputKeyDown(KeyCode.S))
        {
            print("S");
        }
        else if (MyInput.MyInputKeyDown(KeyCode.D))
        {
            print("D");
        }
        else if (MyInput.MyInputKeyDown(KeyCode.F))
        {
            print("F");
        }
        else if (MyInput.MyInputKeyDown(KeyCode.G))
        {
            print("G");
        }
        else if (MyInput.MyInputKeyDown(KeyCode.H))
        {
            print("H");
        }
        else if (MyInput.MyInputKeyDown(KeyCode.J))
        {
            print("J");
        }
        else if (MyInput.MyInputKeyDown(KeyCode.K))
        {
            print("K");
        }
        else if (MyInput.MyInputKeyDown(KeyCode.L))
        {
            print("L");
        }
        else if (MyInput.MyInputKeyDown(KeyCode.Q))
        {
            print("Q");
        }
        else if (MyInput.MyInputKeyDown(KeyCode.W))
        {
            print("W");
        }
        else if (MyInput.MyInputKeyDown(KeyCode.E))
        {
            print("E");
        }
        else if (MyInput.MyInputKeyDown(KeyCode.R))
        {
            print("R");
        }
        else if (MyInput.MyInputKeyDown(KeyCode.T))
        {
            print("T");
        }
        else if (MyInput.MyInputKeyDown(KeyCode.Y))
        {
            print("Y");
        }
        else if (MyInput.MyInputKeyDown(KeyCode.U))
        {
            print("U");
        }
        else if (MyInput.MyInputKeyDown(KeyCode.I))
        {
            print("I");
        }
        else if (MyInput.MyInputKeyDown(KeyCode.O))
        {
            print("O");
        }
        else if (MyInput.MyInputKeyDown(KeyCode.P))
        {
            print("P");
        }
        else if (MyInput.MyInputKeyDown(KeyCode.Alpha1))
        {
            print("1");
        }
        else if (MyInput.MyInputKeyDown(KeyCode.Alpha2))
        {
            print("2");
        }
        else if (MyInput.MyInputKeyDown(KeyCode.Alpha3))
        {
            print("3");
        }
        else if (MyInput.MyInputKeyDown(KeyCode.Alpha4))
        {
            print("4");
        }
        else if (MyInput.MyInputKeyDown(KeyCode.Alpha5))
        {
            print("5");
        }
        else if (MyInput.MyInputKeyDown(KeyCode.Alpha6))
        {
            print("6");
        }
        else if (MyInput.MyInputKeyDown(KeyCode.Alpha7))
        {
            print("7");
        }
        else if (MyInput.MyInputKeyDown(KeyCode.Alpha8))
        {
            print("8");
        }
        else if (MyInput.MyInputKeyDown(KeyCode.Alpha9))
        {
            print("9");
        }
        else if (MyInput.MyInputKeyDown(KeyCode.Alpha0))
        {
            print("0");
        }
        else if (MyInput.MyInputKeyDown(KeyCode.Minus))
        {
            print("-");
        }
        else if (MyInput.MyInputKeyDown(KeyCode.Caret))
        {
            print("^");
        }

        else if (MyInput.MyInputKeyDown(KeyCode.Semicolon))
        {
            print(";");
        }
        else if (MyInput.MyInputKeyDown(KeyCode.Colon))
        {
            print(":");
        }

        else if (MyInput.MyInputKeyDown(KeyCode.At))
        {
            print("@");
        }

        else if (MyInput.MyInputKeyDown(KeyCode.Comma))
        {
            print(",");
        }
        else if (MyInput.MyInputKeyDown(KeyCode.Period))
        {
            print(".");
        }

        else if (MyInput.MyInputKeyDown(KeyCode.Slash))
        {
            print("/");
        }
        else if (MyInput.MyInputKeyDown(KeyCode.LeftBracket))
        {
            print("]");
        }
        else if (MyInput.MyInputKeyDown(KeyCode.RightBracket))
        {
            print("[");
        }
        else
        {
            //なんかtrueにする
        }
        //trueじゃなければHPマイナス
        if (MyInput.MyInputKeydown(KeyCode.Space, 1 / 2))
        {
            print("3秒待つと押せるよ");
        }
    }
}
